
public class Truck extends Vehicle {

	public boolean hasSideStep;
	public int TowCapaciity;
	
	
	
	
	
	public Truck(String make, String model, boolean isFourWheelDrive,
			double retailPrice, int milesPerGallon, boolean hasSideStep,
			int towCapaciity)
	{
		super(make, model, isFourWheelDrive, retailPrice, milesPerGallon);
		this.hasSideStep = hasSideStep;
		TowCapaciity = towCapaciity;
	}
	public boolean isHasSideStep() 
	{
		return hasSideStep;
	}
	public void setHasSideStep(boolean hasSideStep)
	{
		this.hasSideStep = hasSideStep;
	}
	public int getTowCapaciity()
	{
		return TowCapaciity;
	}
	public void setTowCapaciity(int towCapaciity)
	{
		TowCapaciity = towCapaciity;
	}
	
	
	
	public void printVehicle()
	{
		super.printVehicle();
		if(isHasSideStep() == true)
		{
			System.out.println("Has Side Steps");
		}
		else
		{
			System.out.println("No Side Step");
		}
		
		System.out.println("Tows up to " + TowCapaciity + " tons");
		
	}
	
	
	
	
}
