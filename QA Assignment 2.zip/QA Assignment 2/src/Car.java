
public class Car extends Vehicle {
	
	
	public boolean isConvertable;

	
	
	
	public Car(String make, String model, boolean isFourWheelDrive,
			double retailPrice, int milesPerGallon, boolean isConvertable) 
	{
		super(make, model, isFourWheelDrive, retailPrice, milesPerGallon);
		this.isConvertable = isConvertable;
	}

	public boolean isConvertable() 
	{
		return isConvertable;
	}

	public void setConvertable(boolean isConvertable) 
	{
		this.isConvertable = isConvertable;
	}
	
	
	
	public void printVehicle() {
		
		super.printVehicle();
		if(isConvertable == true)
		System.out.println("Covertable");
		
		
	}

}
