
public class Vehicle {

	
	public String Make;
	public String Model;
	public boolean isFourWheelDrive;
	public double RetailPrice;
	
	
	
	
	public Vehicle(String make, String model, boolean isFourWheelDrive,
			double retailPrice, int milesPerGallon)
	{
	
		Make = make;
		Model = model;
		this.isFourWheelDrive = isFourWheelDrive;
		RetailPrice = retailPrice;
		this.milesPerGallon = milesPerGallon;
	}
	public String getMake()
	{
		return Make;
	}
	public void setMake(String make)
	{
		Make = make;
	}
	public String getModel() 
	{
		return Model;
	}
	public void setModel(String model) 
	{
		Model = model;
	}
	public boolean isFourWheelDrive() 
	{
		return isFourWheelDrive;
	}
	
	public void setFourWheelDrive(boolean isFourWheelDrive)
	{
		this.isFourWheelDrive = isFourWheelDrive;
	}
	public double getRetailPrice() 
	{
		return RetailPrice;
	}
	public void setRetailPrice(double retailPrice)
	{
		RetailPrice = retailPrice;
	}
	public int getMilesPerGallon()
	{
		return milesPerGallon;
	}
	public void setMilesPerGallon(int milesPerGallon) 
	{
		this.milesPerGallon = milesPerGallon;
	}
	public int milesPerGallon;
	
	
	public void printVehicle()
	{
		System.out.println(Make + " " + Model);
		if (isFourWheelDrive == true)
		System.out.println("4WD");
		System.out.println("$" + RetailPrice);
		System.out.println(milesPerGallon + "MPG");
		
		
	}
}
